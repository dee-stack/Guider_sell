const inputs = document.querySelectorAll(".input");

function addcl(){
    let parent = this.parentNode.parentNode;
    parent.classList.add("focus");
}

function remcl(){
    let parent = this.parentNode.parentNode;
    if(this.value == ""){
        parent.classList.remove("focus");
    }
   
}

$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});


// prevent form submit
const form = document.querySelector("form");
form.addEventListener('submit', function (e) {
    e.preventDefault();
});

inputs.forEach(input => {
    input.addEventListener("focus", addcl);
    input.addEventListener("blur", remcl)
});
 
    var icon = document.querySelector('.fas');
    if (newp.type === "password") {
        newp.type = "text";
        icon.style.color = "white";
    } else{
        newp.type = "password";
        icon.style.color = "white";
    }



     function validateForm(){
    if(email == "") {  
        document.getElementById("blankMsg").innerHTML = "Enter email";  
        return false;  
      }   
      
      //check empty password field  
      if(newp == "") {  
        document.getElementById("message1").innerHTML = "No password entered!";  
        return false;  
      }  
      
      //check empty confirm password field  
      if(conp == "") {  
        document.getElementById("message2").innerHTML = "No password entered";  
        return false;  
      }   
       
      //minimum password length validation  
      if(newp.length < 8) {  
        document.getElementById("message1").innerHTML = "Password length must be atleast 8 characters";  
        return false;  
      }  
    
      //maximum length of password validation  
      if(newp.length > 15) {  
        document.getElementById("message1").innerHTML = "Password length must not exceed 15 characters";  
        return false;  
      }  

      if(conp.length < 8) {  
        document.getElementById("message1").innerHTML = "Password length must be atleast 8 characters";  
        return false;  
      }  
    
      //maximum length of password validation  
      if(conp.length > 15) {  
        document.getElementById("message1").innerHTML = "Password length must not exceed 15 characters";  
        return false;  
      }  
      
      if(newp != conp) {  
        document.getElementById("message2").innerHTML = "Passwords are not same";  
        return false;  
      } else {  
        alert ("Password re-set successful");   
      }  
    }

  <form onsubmit ="return validateForm()">  
  <span id = "blankMsg" style="color:red"> </span>  
  <span id = "charMsg" style="color:red"> </span>
  <span id = "message1" style="color:red"> </span>  
  <span id = "message2" style="color:red"> </span>
  </form>  